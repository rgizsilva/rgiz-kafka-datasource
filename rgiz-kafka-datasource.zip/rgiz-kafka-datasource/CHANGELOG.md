# Changelog

## 0.0.2 (Unreleased)

Improved checking to handle missing data source config

## 0.0.1 (Unreleased)

Initial release
